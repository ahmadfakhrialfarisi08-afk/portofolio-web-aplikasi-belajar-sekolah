LILY_SYSTEM - Sprite Sheet Frames
=================================

6 kategori x 15 frame = 90 frame.
Semua frame disimpan sebagai PNG RGBA.

Catatan: crop dibuat berdasarkan grid sprite sheet. Jika posisi frame
pada source berbeda, sesuaikan row_y_ranges/kolom pada script.
